package elia.shapira.elimorse;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class ExerciseGame extends AppCompatActivity {

    Context context;
    int NOfTry=0,QuestionNum=0,FailedAttempts=0;
    TextView tvQuestion,tvInputNumber,tvTryNum1,tvQuestionNum,tvTryNum2,tvTryNum3;
    String stAnswer="", currentString_m , currentString_e,ExerciseKind, stDate="";
    int GameType=-1,StringPositionIndex,maxEditTextSize=30,year, month, day;
    Button bDash,bSpace,bDot,bReady,bClear,bRemove;
    HelperDB helperDB;
    SQLiteDatabase db;
    Calendar calander;
    User user;
    String[] e_numbers={"0","1","2","3","4","5","1","7","8","9"};
    String[] m_numbers={"-----", ".----","..---","...--","....-",".....","-....","--...","---..","----."};
    String[] e_words={"DOG","CAT","BIRD","HAT","RUN","JUMP","BOOK"
            ,"PEN","EAT","SLEEP","COMPUTER","LANGUAGE","INTERNET","MESSAGE"
            ,"TRANSMIT","RECEIVE","ENCRYPT","DECODE","NAVIGATE","TELEGRAM"};
    String[] m_words={"-.. --- --.","-.-. .- -","-... .. .-. -..",".... .- -"
            , ".-. ..- -.",".--- ..- -- .--.","-... --- --- -.-",".--. . -."
            ,". .- -","... .-.. . . .--.","-.-. --- -- .--. ..- - . .-."
            ,".-.. .- -. --. ..- .- --. .",".. -. - . .-. -. . -"
            ,"-- . ... ... .- --. .","- .-. .- -. ... -- .. -"
            ,".-. . -.-. . .. ...- .",". -. -.-. .-. -.-- .--. -"
            ,"-.. . -.-. --- -.. .","-. .- ...- .. --. .- - ."
            ,"- . .-.. . --. .-. .- --"};
    String[] e_letters={"A","B","C","D","E","F","G","H","I","J","K","L"
            ,"M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
    String[] m_letters={".-","-...","-.-.","-..",".","..-.","--.","....","..",".---","-.-",".-.."
            ,"--","-.","---",".--.","--.-",".-.","...","-","..-","...-",".--","-..-","-.--","--.."};

    String[][] Strings={m_numbers,m_words,m_letters};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_game);
        Bundle extra = getIntent().getExtras();
        assert extra != null;
        GameType = extra.getInt("KEY_SENDER");


        initElements();

        currentString_e = AnswerGenerator();//(int) (1 + (Math.random()*99));
        tvQuestion.setText(""+ currentString_e);
        currentString_m =toMorse();

        //Intent receiverIntent = getIntent();

        bReady.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //stAnswer+="/";

                //Toast.makeText(context, ""+stAnswer+" , "+stOk, Toast.LENGTH_LONG).show();
                if (stAnswer.equals(currentString_m)){
                    //mps[2].start();

                    QuestionNum++;
                    if(QuestionNum==10) {
                        //Toast.makeText(context, "End", Toast.LENGTH_LONG).show();

                        //Insert to database
                        db=helperDB.getWritableDatabase();
                        ContentValues contentValues=new ContentValues();
                        contentValues.put(helperDB.EXERCISE_KIND, ExerciseKind);
                        contentValues.put(helperDB.EXERCISE_MISTAKES, FailedAttempts);
                        contentValues.put(helperDB.EXERCISE_DATE, stDate);
                        contentValues.put(helperDB.EXERCISE_USER,user.getUserPassword());
                        db.insert(helperDB.TABLE_EXERCISE, null, contentValues);
                        db.close();

                        //Show Alert Dialog
                        AlertDialog.Builder adb=new AlertDialog.Builder(context);
                        adb.setTitle("Your results");
                        adb.setMessage("Finished with "+FailedAttempts+" Mistakes!");
                        adb.setCancelable(false);
                        adb.setPositiveButton("To Dashboard", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Intent goDash=new Intent(context, DashBoard.class);
                                goDash.putExtra("user",user);
                                startActivity(goDash);
                            }
                        });

                        /** adb.setNegativeButton("Play Again", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent goExerciseGame=new Intent(context, ExerciseGame.class);
                                startActivity((goExerciseGame));
                            }
                        });**/

                        adb.create().show();
                    }
                    resetAfterQuestion();
                    tvQuestionNum.setText(QuestionNum+"/10");
                    //pbQuestionNum.setProgress(pbQuestionNum.getProgress()+1);
                }
                else{
                    //mps[3].start();
                    NOfTry++;
                    FailedAttempts++;
                    if(NOfTry==3) {bReady.setClickable(false);tvQuestion.setText("XXX");
                        AlertDialog.Builder adb=new AlertDialog.Builder(context);
                        adb.setTitle("Failed!");
                        adb.setMessage("striked 3 times... Better luck net time!\n"+
                                "correct answer: '"+currentString_e+"' "+currentString_m);
                        adb.setCancelable(false);
                        adb.setPositiveButton("To Dashboard", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent goDash=new Intent(context, DashBoard.class);
                                startActivity(goDash);
                            }
                        });
                        /** adb.setNegativeButton("Try Again", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent goExerciseGame=new Intent(context, ExerciseGame.class);
                                startActivity((goExerciseGame));
                            }
                        }); **/
                        adb.create().show();
                    }
                }
                switch(NOfTry) {
                    case 1:
                        tvTryNum1.setText("Ø");
                        tvTryNum1.setTextColor(getColor(R.color.light_red));
                        break;
                    case 2:
                        tvTryNum2.setText("Ø");
                        tvTryNum2.setTextColor(getColor(R.color.light_red));
                        break;
                    case 3:
                        tvTryNum3.setText("Ø");
                        tvTryNum3.setTextColor(getColor(R.color.light_red));
                        break;
                    case 0:
                        break; //TODO how to change shadow color
                }
            }
        });


        bDash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //mps[0].start();
                if(stAnswer.length()<maxEditTextSize)
                    stAnswer+="-";
                tvInputNumber.setText(stAnswer);

            }
        });
        bSpace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(stAnswer.length()<maxEditTextSize)
                    stAnswer+=" ";
                tvInputNumber.setText(stAnswer);
            }
        });
        bDot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //mps[1].start();
                if(stAnswer.length()<maxEditTextSize)
                    stAnswer+=".";
                tvInputNumber.setText(stAnswer);
            }
        });

        bClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stAnswer="";
                tvInputNumber.setText(stAnswer);

            }
        });
        bRemove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                StringBuilder sb = new StringBuilder(stAnswer);
                if(stAnswer.isEmpty()) return;
                sb.deleteCharAt(stAnswer.length()-1);
                tvInputNumber.setText(sb.toString());
                stAnswer=sb.toString();
            }
        });

        /*tvQuestion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, "stAnswer="+stAnswer+
                        "\nstOK="+stOk+
                        "\nn="+n+
                        "\nNOfTry="+NOfTry, Toast.LENGTH_LONG).show();
                tvInputNumber.setText(currentString_m);stAnswer= currentString_m;
            }
        });*/
    }

    /* @Override
    public void onBackPressed() {
        // Create an AlertDialog
        super.onBackPressed();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Are you sure you want to exit?");
        builder.setMessage("Do You Want To Lose The Progress?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Finish the activity if the user confirms
                finish();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Dismiss the dialog if the user cancels
                dialog.dismiss();
            }
        });

        // Show the AlertDialog
        builder.show();
    } */

    private void initElements() {
        context=this;
        Intent TakeIt = getIntent();
        user = (User) TakeIt.getSerializableExtra("user");
        helperDB = new HelperDB(context);
        tvInputNumber=findViewById(R.id.tvInputNumber);
        bDash=findViewById(R.id.bDash);
        bSpace=findViewById(R.id.bSpace);
        bDot=findViewById(R.id.bDot);
        bClear=findViewById(R.id.bClear);
        bRemove=findViewById(R.id.bRemove);
        bReady=findViewById(R.id.bReady);
        tvQuestion=findViewById(R.id.tvQuestion);
        tvTryNum1=findViewById(R.id.tvTryNum1);
        tvTryNum2=findViewById(R.id.tvTryNum2);
        tvTryNum3=findViewById(R.id.tvTryNum3);
        tvQuestionNum=findViewById(R.id.tvQuestionNum);
        //pbQuestionNum=findViewById(R.id.pbQuestionNum);
        calander=Calendar.getInstance();
        year = calander.get(Calendar.YEAR);
        month = calander.get(Calendar.MONTH)+1;
        day = calander.get(Calendar.DAY_OF_MONTH);
        stDate = ""+day+"/"+month+"/"+year;
        Toast.makeText(context, ""+stDate, Toast.LENGTH_SHORT).show();
        if(GameType==0) ExerciseKind="Numers";
        if(GameType==1) ExerciseKind="Words";
        if(GameType==2) ExerciseKind="Letters";
    }
    public String AnswerGenerator(){
        if (GameType == 0) { StringPositionIndex = (int)(Math.random() * 100); return String.valueOf(StringPositionIndex);}
        if (GameType == 1) { StringPositionIndex = (int) (Math.random() * e_words.length); return e_words[StringPositionIndex];}
        if (GameType == 2) { StringPositionIndex = (int) (Math.random() * e_letters.length); return e_letters[StringPositionIndex];}
        return null;
    }

    private String toMorse() {
        if (GameType != 0)
        {
            return Strings[GameType][StringPositionIndex];
        }
        currentString_m ="";
        String temp=""+currentString_e;
        for (int i = 0; i < temp.length(); i++) {
            int position=(int)temp.charAt(i)-48;
            currentString_m +=m_numbers[position];
            if(i!=temp.length()-1)
                currentString_m +=" ";
        }
        //stOk = stOk.replace(stOk.substring(stOk.length()-1), "");
        return currentString_m;
    }
    private Void resetAfterQuestion(){
        currentString_e = AnswerGenerator(); //reset question value
        tvQuestion.setText(""+ currentString_e); // reset question field
        tvInputNumber.setText(""); //reset answer field
        currentString_m =toMorse(); //set correct answer value
        stAnswer=""; //reset answer value
        NOfTry=0;tvTryNum1.setText("O");tvTryNum2.setText("O");tvTryNum3.setText("O");
        tvTryNum1.setTextColor(getColor(R.color.green));
        tvTryNum2.setTextColor(getColor(R.color.green));
        tvTryNum3.setTextColor(getColor(R.color.green));
        return null;
    }
}
