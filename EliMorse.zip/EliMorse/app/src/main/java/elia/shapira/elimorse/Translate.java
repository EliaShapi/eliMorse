package elia.shapira.elimorse;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;

import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

//Flash
import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Handler;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class Translate extends AppCompatActivity {

    Context context;
    TextView tvTranslateOutcome, tvMenu;
    EditText etTranslateIncome;
    Button bAudio,bSwitch,bFlashlight,bDictionary,bTranslate,bManualFlashlight;
    private static final String[] morseLetters = { ".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....", "..", ".---", "-.-", ".-..",
            "--", "-.", "---", ".--.", "--.-", ".-.", "...", "-", "..-", "...-", ".--", "-..-",
            "-.--", "--.."};
    private static final String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    private final String[][] morse = {
            {"A", ".-"},
            {"B", "-..."},
            {"C", "-.-."},
            {"D", "-.."},
            {"E", "."},
            {"F", "..-."},
            {"G", "--."},
            {"H", "...."},
            {"I", ".."},
            {"J", ".---"},
            {"K", "-.-"},
            {"L", ".-.."},
            {"M", "--"},
            {"N", "-."},
            {"O", "---"},
            {"P", ".--."},
            {"Q", "--.-"},
            {"R", ".-."},
            {"S", "..."},
            {"T", "-"},
            {"U", "..-"},
            {"V", "...-"},
            {"W", ".--"},
            {"X", "-..-"},
            {"Y", "-.--"},
            {"Z", "--.."},
            {"0", "-----"},
            {"1", ".----"},
            {"2", "..---"},
            {"3", "...--"},
            {"4", "....-"},
            {"5", "....."},
            {"6", "-...."},
            {"7", "--..."},
            {"8", "---.."},
            {"9", "----."},
    };
    int what_switch=0,resourceId, i=0;;
    boolean flag1 = true;
    String stText="", stAnswer="", stMorse="", st="";
    MediaPlayer mediaPlayer;
    User user;

    //Flash
    private CameraManager cameraManager;
    private String cameraId;
    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_translate);

        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.CAMERA},200);

        initElements();

        bSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                what_switch++;
                if (what_switch%2==0) {
                    bSwitch.setText("Text to Morse");
                }
                else {
                    bSwitch.setText("Morse to text");
                }
            }
        });

        bTranslate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stAnswer=etTranslateIncome.getText().toString();
                if (what_switch%2==0 && isText(stAnswer)) {
                    toMorse(stAnswer);
                }
                if (what_switch%2!=0 && isMorse(stAnswer)) {  //!!!!!!!!!!!!
                    toText(stAnswer);
                }
            }
        });

        bDictionary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goGuideList = new Intent(context, GuideList.class);
                startActivity(goGuideList);
            }
        });

        bAudio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (what_switch%2==0) {
                    //Text
                    stText=etTranslateIncome.getText().toString();
                    Intent goService=new Intent(context, TTS_Service.class);
                    goService.putExtra("what",stText);
                    startService(goService);
                    String st=tvTranslateOutcome.getText().toString();
                    Toast.makeText(context, ""+st, Toast.LENGTH_SHORT).show();
                    playSequence(st);
                }
                else {
                    //Morse
                    stAnswer=etTranslateIncome.getText().toString();
                    String[] morseArray=stAnswer.split("/");
                    String st="";
                    for (int i = 0; i < morseArray.length; i++) {
                        st+=morseArray[i];
                    }
                    playSequence(st);
                }
            }
        });

        bFlashlight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                st="";
                FlashlightController(context);
                if (what_switch%2==0) {
                    //Text
                    st=tvTranslateOutcome.getText().toString();
                    Toast.makeText(context, ""+st, Toast.LENGTH_SHORT).show();
                }
                else {
                    //Morse
                    stAnswer=etTranslateIncome.getText().toString();
                    String[] morseArray=stAnswer.split("/");
                    for (int i = 0; i < morseArray.length; i++) {
                        st+=morseArray[i];
                    }
                }
                if (st.equals(""))  {
                    My_Toast.showToast(context,"Code Morse is empty, sorry");
                    return;
                }
                flashMorseCode(st);
            }
        });

        tvMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopupMenu();
            }
        });
    }

    //Flash
    public void FlashlightController(Context context) {
        this.context = context;
        cameraManager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
        try {
            cameraId = cameraManager.getCameraIdList()[0];
        } catch (CameraAccessException e) {
            tvTranslateOutcome.setText(e.toString());
        }
    }

    public void flashMorseCode(String morseCode) {
        for (int i = 0; i < morseCode.length(); i++) {
            char symbol = morseCode.charAt(i);
            int delay = (symbol == '.') ? 250 : 500;

            final int index = i;
            handler.postDelayed(() -> {
                try {
                    cameraManager.setTorchMode(cameraId, true);
                    handler.postDelayed(() -> {
                        try {
                            cameraManager.setTorchMode(cameraId, false);
                        } catch (CameraAccessException e) {
                            e.printStackTrace();
                        }
                    }, delay);
                } catch (CameraAccessException e) {
                    e.printStackTrace();
                }
            }, (index == 0 ? 0 : delay * index * 2)); // multiply by 2 to include off time
        }
    }

    private void toText(String stAnswer) {
        String[] morseArray=stAnswer.split("/");
        //Toast.makeText(context, ""+morseArray.length, Toast.LENGTH_SHORT).show();
        stText="";
        for (int i = 0; i < morseArray.length; i++) {
            for (int j = 0; j < morse.length; j++) {
                if (morseArray[i].equals(morse[j][1]))
                    stText+=morse[j][0];
            }
        }
        tvTranslateOutcome.setText(stText);
    }

    private void toMorse(String stAnswer) {
        String st=stAnswer.toUpperCase();
       // Toast.makeText(context, ""+st, Toast.LENGTH_SHORT).show();
        stMorse="";
        for (int i = 0; i < st.length(); i++) {
            int index = alphabet.indexOf(st.charAt(i));
           // Toast.makeText(context, ""+index, Toast.LENGTH_SHORT).show();
            stMorse+=morseLetters[index];
        }
        tvTranslateOutcome.setText(stMorse);
    }

    private boolean isMorse(String stAnswer) {
        return stAnswer.matches("[./-]+");
    }

    private boolean isText(String stAnswer) {
        return stAnswer.matches("^[a-zA-Z]+$");
    }

    private void showPopupMenu() {
        PopupMenu popupMenu = new PopupMenu(this, tvMenu);
        popupMenu.getMenuInflater().inflate(R.menu.total_menu, popupMenu.getMenu());
        MenuItem clearMenuItem = popupMenu.getMenu().add(Menu.NONE, 1, 0 ,"Clear");
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int itemID=item.getItemId();
                if (itemID==R.id.guide) {
                    Intent go = new Intent(context,Guide.class);
                    go.putExtra("user", user);
                    say_what("reminder part");
                    startActivity(go);
                }
                if (itemID==R.id.credits) {
                    Intent go = new Intent(context,AboutMe.class);
                    go.putExtra("user", user);
                    say_what("reminder part");
                    startActivity(go);
                }
                if (itemID==R.id.reminder) {
                    Intent go = new Intent(context,Reminder.class);
                    go.putExtra("user", user);
                    say_what("reminder part");
                    startActivity(go);
                }
                if (itemID==R.id.back) {
                    finish();
                }
                if (itemID==R.id.exit) {
                    finishAffinity();
                }
                if (itemID==1)  {
                    tvTranslateOutcome.setText("");
                    etTranslateIncome.setText("");
                }
                return true;
            }
        });
        popupMenu.show();
    }

    private void say_what(String say_this) {
        Intent goService=new Intent(context, TTS_Service.class);
        goService.putExtra("what","You go to the section "+say_this);
        startService(goService);
    }

    public void playSequence(String st) {
        i=0;
        new CountDownTimer(st.length() * 600, 500) {
            @Override
            public void onTick(long millisUntilFinished) {
                if (i<st.length()) {
                    char what = st.charAt(i);
                    if (what == '.')
                        resourceId = R.raw.dot1;
                    else
                        resourceId = R.raw.dash1;
                    mediaPlayer = MediaPlayer.create(context, resourceId);
                    mediaPlayer.start();
                }
                i++;
            }

            @Override
            public void onFinish() {
                if (mediaPlayer != null) {
                    mediaPlayer.stop();
                    mediaPlayer.release();
                }
            }
        }.start();
    }


    private void initElements() {
        context=Translate.this;
        Intent TakeIt = getIntent();
        user = (User) TakeIt.getSerializableExtra("user");
        etTranslateIncome= (EditText) findViewById(R.id.etTranslateIncome);
        tvTranslateOutcome= (TextView) findViewById(R.id.tvTranslateOutcome);
        bAudio =(Button) findViewById(R.id.bAudio);
        bAudio =(Button) findViewById(R.id.bAudio);
        bSwitch =(Button) findViewById(R.id.bSwitch);
        bFlashlight =(Button) findViewById(R.id.bFlashlight);
        bDictionary =(Button) findViewById(R.id.bDictionary);
        bTranslate =(Button) findViewById(R.id.bTranslate);
        bManualFlashlight =(Button) findViewById(R.id.bManualFlashlight);
        tvMenu= (TextView) findViewById(R.id.tvMenu);
        if (what_switch%2==0) {
            bSwitch.setText("Text to Morse");
        }
        else {
            bSwitch.setText("Morse to text");
        }
    }
}