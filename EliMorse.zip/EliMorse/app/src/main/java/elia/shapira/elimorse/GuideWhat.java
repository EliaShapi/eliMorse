package elia.shapira.elimorse;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class GuideWhat extends AppCompatActivity {

    TextView tvMenu;
    Intent takeit;
    User user;
    Context context=this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide_what);

        iniElements();

        tvMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopupMenu();
            }
        });
    }

    private void iniElements() {
        Intent takeit=getIntent();
        user=(User)takeit.getSerializableExtra("user"); 
        tvMenu=findViewById(R.id.tvMenuGW);
    }

    private void showPopupMenu() {
        PopupMenu popupMenu = new PopupMenu(this, tvMenu);
        popupMenu.getMenuInflater().inflate(R.menu.total_menu, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int itemID=item.getItemId();
                if (itemID==R.id.guide) {
                    Intent go = new Intent(context,Guide.class);
                    go.putExtra("user", user);
                    say_what("reminder part");
                    startActivity(go);
                }
                if (itemID==R.id.credits) {
                    Intent go = new Intent(context,AboutMe.class);
                    go.putExtra("user", user);
                    say_what("reminder part");
                    startActivity(go);
                }
                if (itemID==R.id.reminder) {
                    Intent go = new Intent(context,Reminder.class);
                    go.putExtra("user", user);
                    say_what("reminder part");
                    startActivity(go);
                }
                if (itemID==R.id.back) {
                    finish();
                }
                if (itemID==R.id.exit) {
                    finishAffinity();
                }
                return true;
            }
        });
        popupMenu.show();
    }

    private void say_what(String say_this) {
        Intent goService=new Intent(this, TTS_Service.class);
        goService.putExtra("what","You go to the section "+say_this);
        startService(goService);
    }

}