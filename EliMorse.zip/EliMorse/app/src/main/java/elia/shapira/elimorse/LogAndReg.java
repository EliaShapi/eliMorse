package elia.shapira.elimorse;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class LogAndReg extends AppCompatActivity {

    LoginFragment fLogin;
    RegistryFragment fRegister;
    RadioButton rbLogin;
    RadioButton rbRegister;
    Button bConfirm;
    TextView tvGuest, tvMenu;
    Context context;
    FrameLayout FL;
    String stName, stPassword, stMail, stPhone;
    HelperDB helperDB;
    SQLiteDatabase db;
    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_and_reg);

        initElements();

        rbLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (rbLogin.isChecked())  {
                    fLogin=new LoginFragment();
                    FragmentTransaction ft=getSupportFragmentManager().beginTransaction();
                    ft.replace(R.id.FL, fLogin);
                    ft.commit();
                }
            }
        });

        rbRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (rbRegister.isChecked())  {
                    fRegister=new RegistryFragment();
                    FragmentTransaction ft=getSupportFragmentManager().beginTransaction();
                    ft.replace(R.id.FL, fRegister);
                    ft.commit();
                }
            }
        });

        bConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(rbRegister.isChecked()){
                    stName=fRegister.etName.getText().toString();
                    if (stName.equals(""))  {
                        Toast.makeText(context, "Name field is EMPTY!", Toast.LENGTH_LONG).show();
                        return;
                    }
                    stPassword=fRegister.etPassword.getText().toString();
                    if (stPassword.equals(""))  {
                        Toast.makeText(context, "Password field is EMPTY!", Toast.LENGTH_LONG).show();
                        return;
                    }
                    stMail=fRegister.etMail.getText().toString();
                    if (stMail.equals(""))  {
                        Toast.makeText(context, "E-mail field is EMPTY!", Toast.LENGTH_LONG).show();
                        return;
                    }
                    stPhone=fRegister.etPhone.getText().toString();
                    if (stPhone.equals(""))  {
                        Toast.makeText(context, "Phone's number field is EMPTY!", Toast.LENGTH_LONG).show();
                        return;
                    }
                    if (!isUserFound(stName,stPassword))  {
                        db=helperDB.getWritableDatabase();
                        ContentValues contentValues=new ContentValues();
                        contentValues.put(helperDB.USER_NAME, stName);
                        contentValues.put(helperDB.USER_PASSWORD, stPassword);
                        contentValues.put(helperDB.USER_EMAIL, stMail);
                        contentValues.put(helperDB.USER_PHONE, stPhone);
                        db.insert(helperDB.TABLE_USER, null, contentValues);
                        db.close();
                        user=new User(stName,stPassword,stPhone,stMail);
                        Intent go=new Intent(context, DashBoard.class);
                        go.putExtra("user", user);
                        startActivity(go);
                    }
                    else  {
                        Toast.makeText(context, "Enter other name or password, please", Toast.LENGTH_LONG).show();
                    }
                }
                if (rbLogin.isChecked()) {
                    stName = fLogin.etNameL.getText().toString();
                    if (stName.equals("")) {
                        Toast.makeText(context, "Name field is EMPTY!", Toast.LENGTH_LONG).show();
                        return;
                    }
                    stPassword = fLogin.etPasswordL.getText().toString();
                    if (stPassword.equals("")) {
                        Toast.makeText(context, "Password field is EMPTY!", Toast.LENGTH_LONG).show();
                        return;
                    }
                    if (isUserFound(stName,stPassword))  {
                        Intent go=new Intent(context, DashBoard.class);
                        go.putExtra("user",user);
                        startActivity(go);
                    }
                    else {
                        My_Toast.showToast(context,"User not found!");
                        return;
                    }
                }

            }
        });
    }

    private boolean isUserFound(String stName, String stPassword) {
        boolean flag=false;

        db=helperDB.getReadableDatabase();
        Cursor cursor=db.query(helperDB.TABLE_USER,
                null,null,null,
                null,null,null);
        if (cursor.getCount()==0) {
            db.close();
            return flag;
        }
        cursor.moveToFirst();
        while (flag==false && !cursor.isAfterLast())  {
            String pointerName=cursor.getString((int)cursor.getColumnIndex(helperDB.USER_NAME));
            String pointerPassword=cursor.getString((int)cursor.getColumnIndex(helperDB.USER_PASSWORD));
            if (pointerName.equals(stName) || pointerPassword.equals(stPassword))  {
                String pointerPhone=cursor.getString((int)cursor.getColumnIndex(helperDB.USER_PHONE));
                String pointerMail=cursor.getString((int)cursor.getColumnIndex(helperDB.USER_EMAIL));
                user=new User(pointerName,pointerPassword,pointerPhone,pointerMail);
                Toast.makeText(context, ""+user.toString(), Toast.LENGTH_SHORT).show();
                flag=true;
            }
            cursor.moveToNext();
        }
        db.close();
        return flag;
    }

    private void initElements() {
        context=LogAndReg.this;
        tvMenu=findViewById(R.id.tvMenuLAR);
        //fLogin=(Fragment)findViewById(R.id.fLogin);
        //fRegister=(Fragment)findViewById(R.id.fRegister);
        rbLogin=(RadioButton) findViewById(R.id.rbLogin);
        rbRegister=(RadioButton) findViewById(R.id.rbRegister);
        bConfirm=(Button) findViewById(R.id.bConfirm);
        FL=findViewById(R.id.FL);
        helperDB=new HelperDB(context);
        fLogin=new LoginFragment();
        FragmentTransaction ft=getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.FL, fLogin);
        ft.commit();
    }


}