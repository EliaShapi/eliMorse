package elia.shapira.elimorse;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class AboutMe extends AppCompatActivity {

    Context context;
    Button bSMS,bEmail,bCall;
    String UserPassword;
    ConnectivityManager connectivityManager;
    NetworkInfo networkInfo;
    TextView tvMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_me);

        initElements();

        tvMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopupMenu();
            }
        });
        bSMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                networkInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

                if (networkInfo != null && networkInfo.isConnected()) {
                    try {
                        String say="SMS sent";
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage("0586446800", null,
                                say, null, null);
                        Toast.makeText(context, say, Toast.LENGTH_SHORT).show();
                        say_what(say);
                    } catch (Exception e) {
                        String say="Error send SMS";
                        Toast.makeText(context, say, Toast.LENGTH_SHORT).show();
                        say_what(say);
                    }
                } else {
                    String say="Not found connection to mobile net";
                    Toast.makeText(context, say, Toast.LENGTH_SHORT).show();
                    say_what(say);
                }
            }
        });

        bCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                networkInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

                if (networkInfo != null && networkInfo.isConnected()) {
                    // Initiate phone call
                    try {
                        String phoneNumber = "0586446800"; // Replace with the actual phone number
                        Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + phoneNumber));
                        context.startActivity(intent);
                        Toast.makeText(context, "Calling " + phoneNumber, Toast.LENGTH_SHORT).show();
                        say_what("Calling " + phoneNumber); // Assuming say_what handles voice notifications
                    } catch (SecurityException e) {
                        String say = "Call permission denied";
                        Toast.makeText(context, say, Toast.LENGTH_SHORT).show();
                        say_what(say);
                    }
                } else {
                    String say = "Not found connection to mobile net";
                    Toast.makeText(context, say, Toast.LENGTH_SHORT).show();
                    say_what(say);
                }
            }
        });

        bEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

                // Check for any network connection (Wi-Fi or mobile data)
                if (connectivityManager.getActiveNetworkInfo() != null && connectivityManager.getActiveNetworkInfo().isConnected()) {
                    // Send email
                    try {
                        String recipient = "recipient@example.com"; // Replace with the recipient's email address
                        String subject = "Email from your app";
                        String message = "This is the email content";

                        Intent intent = new Intent(Intent.ACTION_SEND);
                        intent.setType("message/rfc822"); // Email MIME type
                        intent.putExtra(Intent.EXTRA_EMAIL, new String[]{recipient});
                        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
                        intent.putExtra(Intent.EXTRA_TEXT, message);

                        // Check if there's an email app installed
                        if (intent.resolveActivity(context.getPackageManager()) != null) {
                            context.startActivity(intent);
                            Toast.makeText(context, "Sending email...", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(context, "No email app found!", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        String say = "Error sending email";
                        Toast.makeText(context, say, Toast.LENGTH_SHORT).show();
                        say_what(say);
                    }
                } else {
                    String say = "Not found connection";
                    Toast.makeText(context, say, Toast.LENGTH_SHORT).show();
                    say_what(say);
                }
            }
        });

    }

    private void showPopupMenu() {
        PopupMenu popupMenu = new PopupMenu(this, tvMenu);
        popupMenu.getMenuInflater().inflate(R.menu.total_menu, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int itemID=item.getItemId();
                if (itemID==R.id.guide) {
                    Intent go = new Intent(context,Guide.class);
                    go.putExtra("password", UserPassword);
                    say_what("reminder part");
                    startActivity(go);
                }
                if (itemID==R.id.credits) {
                    Intent go = new Intent(context,AboutMe.class);
                    go.putExtra("password", UserPassword);
                    say_what("reminder part");
                    startActivity(go);
                }
                if (itemID==R.id.reminder) {
                    Intent go = new Intent(context,Reminder.class);
                    go.putExtra("password", UserPassword);
                    say_what("reminder part");
                    startActivity(go);
                }
                if (itemID==R.id.back) {
                    finish();
                }
                if (itemID==R.id.exit) {
                    finishAffinity();
                }
                return true;
            }
        });
        popupMenu.show();
    }

    private void say_what(String say_this) {
        Intent goService=new Intent(context, TTS_Service.class);
        goService.putExtra("what",say_this);
        startService(goService);
    }

    private void initElements() {
        context=AboutMe.this;
        Intent TakeIt = getIntent();
        UserPassword = TakeIt.getStringExtra("password");
        bSMS=(Button) findViewById(R.id.bSMS);
        bEmail=(Button) findViewById(R.id.bEmail);
        bCall=(Button) findViewById(R.id.bCall);
        tvMenu=findViewById(R.id.tvMenuAboutMe);
    }
}