package elia.shapira.elimorse;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class GuideList extends AppCompatActivity {

    Context context = this;
    ListView lv;
    ArrayList<MorseCode> all;
    ArrayList<String> info;
    ArrayAdapter<String> adapter;
    InputStream is;
    InputStreamReader isr;
    BufferedReader br;
    String st1, st2;
    TextView tvMenu;
    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide_list);

        initElements();

        tvMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopupMenu();
            }
        });
    }

    private void showPopupMenu() {
        PopupMenu popupMenu = new PopupMenu(this, tvMenu);
        popupMenu.getMenuInflater().inflate(R.menu.total_menu, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int itemID=item.getItemId();
                if (itemID==R.id.guide) {
                    Intent go = new Intent(context,Guide.class);
                    go.putExtra("user", user);
                    say_what("reminder part");
                    startActivity(go);
                }
                if (itemID==R.id.credits) {
                    Intent go = new Intent(context,AboutMe.class);
                    go.putExtra("user", user);
                    say_what("reminder part");
                    startActivity(go);
                }
                if (itemID==R.id.reminder) {
                    Intent go = new Intent(context,Reminder.class);
                    go.putExtra("user", user);
                    say_what("reminder part");
                    startActivity(go);
                }
                if (itemID==R.id.back) {
                    finish();
                }
                if (itemID==R.id.exit) {
                    finishAffinity();
                }
                return true;
            }
        });
        popupMenu.show();
    }

    private void say_what(String say_this) {
        Intent goService=new Intent(context, TTS_Service.class);
        goService.putExtra("what","You go to the section "+say_this);
        startService(goService);
    }


    private void initElements() {
        context=this;
        Intent takeit=getIntent();
        user= (User) takeit.getSerializableExtra("user");
        lv=findViewById(R.id.lv);
        all=new ArrayList<>();
        info=new ArrayList<>();
        is=getResources().openRawResource(R.raw.all_morse);
        isr=new InputStreamReader(is);
        br=new BufferedReader(isr);
        try {
            while ((st1 = br.readLine()) != null)  {
                st2=br.readLine();
                MorseCode morseCode=new MorseCode(st1,st2);
                all.add(morseCode);
                info.add(morseCode.toString());
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        adapter=new ArrayAdapter<>(context,
                android.R.layout.simple_list_item_1,info);
        lv.setAdapter(adapter);
        tvMenu=findViewById(R.id.tvMenuGL);
    }
}