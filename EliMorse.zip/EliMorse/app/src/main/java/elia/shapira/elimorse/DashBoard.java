package elia.shapira.elimorse;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.QuickContactBadge;
import android.widget.TextView;

public class DashBoard extends AppCompatActivity {

    Button bExercise,bTranslate,bGuide,bAbout,bHistory,bReminder;
    Context context;
    ImageView ivMenu;
    String UserPassword = "";
    TextView tvMenu;
    User user;

    //TODO add night theme
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board);

        initElements();

        tvMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopupMenu();
            }
        });

        bExercise.setOnClickListener(view -> {
            Intent goExercise = new Intent(context,Exercise.class);
            goExercise.putExtra("user", user);
            say_what("exercise part");
            startActivity(goExercise);

        });

        bTranslate.setOnClickListener(view -> {
            Intent goTranslate = new Intent(context,Translate.class);
            goTranslate.putExtra("user", user);
            say_what("translate part");
            startActivity(goTranslate);

        });

        bGuide.setOnClickListener(view -> {
            Intent goGuide = new Intent(context,Guide.class);
            goGuide.putExtra("user", user);
            say_what("guide part");
            startActivity(goGuide);

        });

        bAbout.setOnClickListener(view -> {
            Intent goAbout = new Intent(context,AboutMe.class);
            goAbout.putExtra("user", user);
            say_what("about me part");
            startActivity(goAbout);

        });
        bHistory.setOnClickListener(view -> {
            Intent goHistory = new Intent(context,History.class);
            goHistory.putExtra("user", user);
            say_what("history part");
            startActivity(goHistory);

        });
        bReminder.setOnClickListener(view -> {
            Intent goReminder = new Intent(context,Reminder.class);
            goReminder.putExtra("user", user);
            say_what("reminder part");
            startActivity(goReminder);
        });
    }

    private void say_what(String say_this) {
        Intent goService=new Intent(context, TTS_Service.class);
        goService.putExtra("what","You go to the section "+say_this);
        startService(goService);
    }

    private void showPopupMenu() {
        PopupMenu popupMenu = new PopupMenu(this, tvMenu);
        popupMenu.getMenuInflater().inflate(R.menu.total_menu, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int itemID=item.getItemId();
                if (itemID==R.id.guide) {
                    Intent go = new Intent(context,Guide.class);
                    go.putExtra("user", user);
                    say_what("reminder part");
                    startActivity(go);
                }
                if (itemID==R.id.credits) {
                    Intent go = new Intent(context,AboutMe.class);
                    go.putExtra("user", user);
                    say_what("reminder part");
                    startActivity(go);
                }
                if (itemID==R.id.reminder) {
                    Intent go = new Intent(context,Reminder.class);
                    go.putExtra("user", user);
                    say_what("reminder part");
                    startActivity(go);
                }
                if (itemID==R.id.back) {
                    finish();
                }
                if (itemID==R.id.exit) {
                    finishAffinity();
                }
                return true;
            }
        });
        popupMenu.show();
    }

    private void initElements() {
        context=DashBoard.this;
        Intent TakeIt = getIntent();
        user = (User) TakeIt.getSerializableExtra("user");
        bExercise = findViewById(R.id.bExercise);
        bTranslate = findViewById(R.id.bTranslate);
        bGuide = findViewById(R.id.bGuide);
        bAbout = findViewById(R.id.bAbout);
        bHistory = findViewById(R.id.bHistory);
        bReminder = findViewById(R.id.bReminder);
        tvMenu=findViewById(R.id.tvMenuDB);

    }
}