package elia.shapira.elimorse;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Guide extends AppCompatActivity {
    Context context;
    ImageView ivMenu;
    Button bWhat,bHow,bList;
    User user;
    TextView tvMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide);

        initElements();

        tvMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopupMenu();
            }
        });

        bWhat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goGuideWhat = new Intent(context, GuideWhat.class);
                startActivity(goGuideWhat);
            }
        });
        bHow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goGuideHow = new Intent(context,GuideHow.class);
                startActivity(goGuideHow);
            }
        });
        bList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goGuideList = new Intent(context,GuideList.class);
                startActivity(goGuideList);
            }
        });
    }

    private void showPopupMenu() {
        PopupMenu popupMenu = new PopupMenu(this, tvMenu);
        popupMenu.getMenuInflater().inflate(R.menu.total_menu, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int itemID=item.getItemId();
                if (itemID==R.id.guide) {
                    Intent go = new Intent(context,Guide.class);
                    go.putExtra("user", user);
                    say_what("reminder part");
                    startActivity(go);
                }
                if (itemID==R.id.credits) {
                    Intent go = new Intent(context,AboutMe.class);
                    go.putExtra("user", user);
                    say_what("reminder part");
                    startActivity(go);
                }
                if (itemID==R.id.reminder) {
                    Intent go = new Intent(context,Reminder.class);
                    go.putExtra("user", user);
                    say_what("reminder part");
                    startActivity(go);
                }
                if (itemID==R.id.back) {
                    finish();
                }
                if (itemID==R.id.exit) {
                    finishAffinity();
                }
                return true;
            }
        });
        popupMenu.show();
    }

    private void say_what(String say_this) {
        Intent goService=new Intent(context, TTS_Service.class);
        goService.putExtra("what","You go to the section "+say_this);
        startService(goService);
    }

    private void initElements() {
        Intent TakeIt = getIntent();
        user = (User) TakeIt.getSerializableExtra("user");
        context=Guide.this;
        bWhat =(Button) findViewById(R.id.bWhat);
        bHow =(Button) findViewById(R.id.bHow);
        bList =(Button) findViewById(R.id.bList);
        tvMenu=findViewById(R.id.tvMenuGuide);
    }
}