package elia.shapira.elimorse;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class Exercise extends AppCompatActivity {

    Context context;
    ImageView ivMenu;
    CheckBox cbHear;
    RadioButton rbNumbers,rbWords,rbLetters;
    Button bNext;
    int gameType=-1;
    User user;
    TextView tvMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise);

        initElements();

        tvMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopupMenu();
            }
        });

        bNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gameType=findGameType();

                if(gameType!=-1){
                    Intent goExerciseGame = new Intent(context,ExerciseGame.class);
                    goExerciseGame.putExtra("KEY_SENDER",gameType);
                    goExerciseGame.putExtra("user",user);
                    startActivity(goExerciseGame);}

                else Toast.makeText(context,"Please Select A Game Type",Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showPopupMenu() {
        PopupMenu popupMenu = new PopupMenu(this, tvMenu);
        popupMenu.getMenuInflater().inflate(R.menu.total_menu, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int itemID=item.getItemId();
                if (itemID==R.id.guide) {
                    Intent go = new Intent(context,Guide.class);
                    go.putExtra("user", user);
                    say_what("reminder part");
                    startActivity(go);
                }
                if (itemID==R.id.credits) {
                    Intent go = new Intent(context,AboutMe.class);
                    go.putExtra("user", user);
                    say_what("reminder part");
                    startActivity(go);
                }
                if (itemID==R.id.reminder) {
                    Intent go = new Intent(context,Reminder.class);
                    go.putExtra("user", user);
                    say_what("reminder part");
                    startActivity(go);
                }
                if (itemID==R.id.back) {
                    finish();
                }
                if (itemID==R.id.exit) {
                    finishAffinity();
                }
                return true;
            }
        });
        popupMenu.show();
    }

    private void say_what(String say_this) {
        Intent goService=new Intent(context, TTS_Service.class);
        goService.putExtra("what","You go to the section "+say_this);
        startService(goService);
    }

    private void initElements() {
        context=Exercise.this;
        Intent TakeIt = getIntent();
        user = (User) TakeIt.getSerializableExtra("user");
        rbNumbers= (RadioButton) findViewById(R.id.rbNumbers);
        rbWords= (RadioButton) findViewById(R.id.rbWords);
        rbLetters= (RadioButton) findViewById(R.id.rbLetters);
        cbHear= (CheckBox) findViewById(R.id.cbHear);
        bNext= (Button) findViewById(R.id.bNext);
        tvMenu=findViewById(R.id.tvMenuExer);
    }

    public int findGameType(){
        if(rbNumbers.isChecked()) return 0;
        if(rbWords.isChecked()) return 1;
        if(rbLetters.isChecked()) return 2;
        else return -1;
    }
}