package elia.shapira.elimorse;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.speech.tts.TextToSpeech;
import android.widget.Toast;

import java.util.Locale;

public class TTS_Service extends Service {

    TextToSpeech tts;
    int language;
    String st="";

    public TTS_Service() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        st=intent.getStringExtra("what");
        Toast.makeText(this, st, Toast.LENGTH_SHORT).show();
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                initializeTextToSpeech();
                //TextToSpeechHelper.speak(st);
            }
        });
        thread.start();
        return START_NOT_STICKY;
    }

    private void initializeTextToSpeech() {
        tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int result = tts.setLanguage(Locale.US);
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Toast.makeText(TTS_Service.this, "Language is not supported", Toast.LENGTH_SHORT).show();
                    } else {
                        //TextToSpeechHelper.speak(st);
                        tts.speak(st, TextToSpeech.QUEUE_FLUSH, null, null);
                    }
                } else {
                    Toast.makeText(TTS_Service.this, "Initialization failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}