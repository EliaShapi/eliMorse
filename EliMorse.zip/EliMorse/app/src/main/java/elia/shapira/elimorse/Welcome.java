package elia.shapira.elimorse;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

import java.util.Locale;

public class Welcome extends AppCompatActivity {

    ImageView ivLogo;
    Button bStart;
    Context context;
    HelperDB helperDB;
    SQLiteDatabase db;
    CountDownTimer cdt;
    String[] speakme={"Seven","Six","Five","Four","Three","Two","One","Welcome to EliMorse"};
    int i=0;
    TextToSpeech tts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        initElements();

        cdt=new CountDownTimer(7000,1000) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                Intent go=new Intent(context, LogAndReg.class);
                startActivity(go);
            }
        };

        cdt.start();


        bStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cdt.cancel();
                Intent go = new Intent(context, LogAndReg.class);
                startActivity(go);

            }
        });

    }

    private void initElements() {
        context=this;
        ivLogo=(ImageView)findViewById(R.id.ivLogo);
        bStart=(Button)findViewById(R.id.bStart);
        helperDB=new HelperDB(context);
        db=helperDB.getWritableDatabase();
        db.close();
        Intent goService=new Intent(context, TTS_Service.class);
        goService.putExtra("what","Welcome to my application");
        startService(goService);
        //Animation popIn = AnimationUtils.loadAnimation(context,R.anim.zoomin);
        //ivLogo.startAnimation(popIn);
        ivLogo.animate().rotation(360f).setDuration(5000).start();
    }
}